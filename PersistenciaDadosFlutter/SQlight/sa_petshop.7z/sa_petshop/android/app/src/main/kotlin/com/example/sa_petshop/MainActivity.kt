package com.example.sa_petshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
